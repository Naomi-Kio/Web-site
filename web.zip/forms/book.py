from flask_wtf import FlaskForm
from wtforms import SubmitField, DateField, SelectField, TimeField
from wtforms.validators import DataRequired


class BookForm(FlaskForm):
    address = SelectField('Клиника', validators=[DataRequired()],
                          choices=("На Кутузовской", "На Тимирязевской",
                                   "На Электрозаводской",
                                   "На Ленинском проспекте"))
    date = DateField('Дата', validators=[DataRequired()])
    time = TimeField('Время', validators=[DataRequired()])
    submit = SubmitField('Отправить')
